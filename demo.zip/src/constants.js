export const routes = {
    home: '/',
    details: '/car-details',
    carDetails: '/car-details/:id',
    myBooking: '/my-booking'
}