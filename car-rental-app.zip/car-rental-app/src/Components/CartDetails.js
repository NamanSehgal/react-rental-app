import React from "react";
import Calendar from 'react-calendar';
import Button from "react-bootstrap/esm/Button";

const CartDetails = () =>
    <div>
        <h3>CarName</h3>

        <h6>Min. Subscription Length</h6>
        <Button as="input" type="button" value="1 Month" />{' '}
        <Button as="input" type="submit" value="6 Months" />{' '}

        <h6>Miles Per Month</h6>
        <Button as="input" type="button" value="800" />{' '}
        <Button as="input" type="submit" value="1000" />{' '}
        <Button as="input" type="button" value="1200" />{' '}
        <h6>Delivery date</h6>
        <p>date</p>
        <Calendar />

        <Button variant="primary" size="lg" block>
            Book Now
        </Button>
    </div>;

export default CartDetails;