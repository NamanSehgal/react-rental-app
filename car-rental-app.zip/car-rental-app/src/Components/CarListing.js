import React from "react";
import { Row, Col, Container, Button } from "react-bootstrap";

class CarListing extends React.Component {
  render() {
    return <Container>
      <Row>
        <Col sm={4}>
          <img
            alt="e-Ride"
            src='/images/car.jpg'
            width="230px"
            height="150px"
            className="d-inline-block align-top"
          />{' '} <br />CarName <br />19kmph <br />Efficiancy <br />
          <Button variant="primary" size="lg" block>
            Book Now
          </Button></Col>
        <Col sm={4}>
          <img
            alt="e-Ride"
            src='/images/car.jpg'
            width="230px"
            height="150px"
            className="d-inline-block align-top"
          />{' '} <br />CarName <br />19kmph <br />Efficiancy <br />
          <Button variant="primary" size="lg" block>
            Book Now
          </Button></Col>
        <Col sm={4}>
          <img
            alt="e-Ride"
            src='/images/car.jpg'
            width="230px"
            height="150px"
            className="d-inline-block align-top"
          />{' '} <br />CarName <br />19kmph <br />Efficiancy <br />
          <Button variant="primary" size="lg" block>
            Book Now
          </Button></Col>
      </Row>
    </Container>
  }
}

export default CarListing;