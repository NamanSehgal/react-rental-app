import React from "react";
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import MyBooking from './MyBooking';

class NavigationBar extends React.Component {
  render() {
    return <Navbar>
      <Navbar.Brand href="#home">
        <img
          alt="e-Ride"
          src='/images/logo192.png'
          width="30"
          height="30"
          className="d-inline-block align-top"
        />{' '}
        e-Ride</Navbar.Brand>
      <Navbar.Collapse className="justify-content-end">
        <Nav>
          <Nav.Item>
            <Nav.Link href="/home">Electric Cars</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link>Suitability Tool</Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link href="/booking">My Booking</Nav.Link>
            <BrowserRouter>
              <Switch>
                <Route path="/booking">
                  <MyBooking />
                </Route>
              </Switch>
            </BrowserRouter>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link disabled>
              Sign Out
            </Nav.Link>
          </Nav.Item>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  }
}
export default NavigationBar;