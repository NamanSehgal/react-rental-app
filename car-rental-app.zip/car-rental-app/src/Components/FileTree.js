import React from "react";

class FileTree extends React.Component {
    render(props) {
        return <div>
            <a href="#">Browse Cars</a> {">"} {this.props.slug}
        </div>
    }
}

export default FileTree;