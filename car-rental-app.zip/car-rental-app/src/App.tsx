import React from 'react';
import NavigationBar from './Components/NavigationBar';
import CarListing from './Components/CarListing';
import Footer from '../src/Components/Footer';
import CarDetails from './Components/CarDetails';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div>
      <NavigationBar />
      <CarListing />
      {/* Sort by 
      <CarListing />
      <Footer /> */}

      {/* <div>
        <CarDetails/>
      </div> */}
    </div>
  );
}

export default App;
