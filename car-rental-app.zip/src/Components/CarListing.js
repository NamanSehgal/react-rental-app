import React, { useEffect } from "react";
import { routes } from '../constants';
import { sortAccordingToKeys } from '../helpers';
import { useHistory } from 'react-router-dom';
import { Row, Col, Container, Button, Dropdown, DropdownButton, InputGroup, FormControl } from "react-bootstrap";
import Footer from './Footer';
import axios from "axios";

const CarListing = () => {
  const [carDetails, setCarDetails] = React.useState('');
  let sort = '';

  const history = useHistory();

  React.useEffect(() => {
    axios.get("https://60d57c33943aa6001776899c.mockapi.io/api/car-listing/all")
      .then(resp => {
        setCarDetails(resp);
      })
      .catch(function (error) {
        console.log(error);
      });
  }, []);

  const handleBookNowClick = (id, name) => {
    console.log('Details', id);
    history.push(`${routes.details}/${id}?name=${name}`);
  }

  const handleChange = (id) => {
    console.log("Selected!!" + id);
    if(id === 1) {
      sort = "asc";
      console.log("Sort: " + sort);
      return;
    }
    sort = "desc";
    console.log("Sort: " + sort);
  }

  return (
    <Container>
      <DropdownButton title="Sort by">
        <Dropdown.Item onClick={() => handleChange(1)}>Price Low to High</Dropdown.Item>
        <Dropdown.Item onClick={() => handleChange(2)}>Price High to Low</Dropdown.Item>
      </DropdownButton>

      <div style={{ whiteSpace: "nowrap", paddingBottom: "10%"}}>
        <Row>
          {sortAccordingToKeys(carDetails.data, 'price', sort).map(({ id, image, name, speed, price, efficiancy }) => (
            <Col lg={3} style={{ padding: "2%", border: "2px solid pink", boxShadow: "10px 10px 5px -3px rgba(255,167,213,0.75)", marginRight: "8%", marginTop: "2%" }}>
              <div style={{ textAlign: "right" }}> From <b>${price}</b>/ mo <br /><p style={{ color: "grey" }}>For 6 months</p></div>
              <div><img alt="e-Ride" src={image} width="230px" height="150px" className="d-inline-block align-top" /></div>
              <div>{name}</div>
              <div> Speed: {speed} </div>
              <div>Efficiancy : {efficiancy} </div>
              <center>
                <Button variant="secondary" size="sm" onClick={() => handleBookNowClick(id, name)}> Explore </Button>
              </center>
            </Col>
          ))}
        </Row >
        <Footer />
      </div>
    </Container >)
}

export default CarListing;